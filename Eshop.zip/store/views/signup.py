from django.shortcuts import render, redirect
from store.models.customer import Customer
from django.contrib.auth.hashers import make_password
from django.views import View


# write your code hare...

class Signup(View):

    def get(self, request):
        if request.method == 'GET':
            return render(request, 'signup.html')

    def validetCustomer(self, customar):
        error_message = None
        if (not customar.first_name):
            error_message = 'First Name Required!!'
        elif len(customar.first_name) < 4:
            error_message = 'First name must be 4 character long.. '

        if (not customar.last_name):
            error_message = 'Last Name Required!!'
        elif len(customar.last_name) < 3:
            error_message = 'last name must be 3 character long.. '

        if (not customar.phone):
            error_message = 'Phone No. Required!!'
        elif len(customar.phone) < 11:
            error_message = 'Phone No. must be 11 digit long.. '

        if (not customar.email):
            error_message = 'Email Required!!'
        elif len(customar.email) < 10:
            error_message = '10 character required!! '

        if (not customar.password):
            error_message = 'Password Required!!'
        elif len(customar.password) < 6:
            error_message = 'Password must be 6 character long.. '

            # email Exist or Not
        if customar.isExists():
            error_message = 'Email Addres Alredy Exist'

        return error_message

    def post(self, request):
        postData = request.POST
        first_name = postData.get('firstname')
        last_name = postData.get('lastname')
        phone = postData.get('phone')
        email = postData.get('email')
        password = postData.get('password')

        error_message = None
        value = {
            'first_name': first_name,
            'last_name': last_name,
            'phone': phone,
            'email': email,
        }

        # Customer Object
        customer = Customer(first_name=first_name,
                            last_name=last_name,
                            phone=phone,
                            email=email,
                            password=password)

        # Validation
        error_message = self.validetCustomer(customer)

        # registery
        if not error_message:
            customer.password = make_password(customer.password)
            customer.register()
            return redirect('homepage')
        else:
            data = {
                'error': error_message,
                'value': value
            }
            return render(request, 'signup.html', data)
