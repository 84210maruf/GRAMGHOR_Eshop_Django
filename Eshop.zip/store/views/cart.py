from django.shortcuts import render,redirect
from store.models.customer import Customer
from django.contrib.auth.hashers import check_password
from django.views import View
from store.models.product import Product

#write your code hare..

class Cart(View):
    def get(self, request):
        List_ids = list(request.session.get('cart').keys())
        products = Product.get_product_by_id(List_ids)
        #print(List_ids)
        return render(request, 'cart.html',{'products':products})